Roc Intermediate Guide — Extracted Code Blocks
Grouped by chapter, preserving order as they appear in the book.
File naming: chapter-XX_Title/code-YY.roc
Note: Detection uses heuristics for code-like lines. Review if any block looks like prose.
